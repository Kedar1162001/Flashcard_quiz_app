from frontend.gui import MainWindow

if __name__ == "__main__":
    app = MainWindow()
    app.mainloop()
